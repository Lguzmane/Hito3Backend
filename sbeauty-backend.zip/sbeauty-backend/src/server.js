const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();
const db = require('./config/db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const authRoutes = require('./routes/authRoutes');
app.use('/api/auth', authRoutes);

const serviciosRoutes = require('./routes/serviciosRoutes');
app.use('/api/servicios', serviciosRoutes);

const reservasRoutes = require('./routes/reservasRoutes');
app.use('/api/reservas', reservasRoutes); 

const reseñasRoutes = require('./routes/resenasRoutes');
app.use('/api/resenas', reseñasRoutes);

app.get('/', (req, res) => {
  res.send('API de SBeauty funcionando');
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});

