const db = require('../config/db');

// Crear nuevo servicio
const crearServicio = async (req, res) => {
  const {
    nombre,
    descripcion,
    precio,
    duracion,
    categoria,
    tipo_atencion,
    comuna,
    imagenes,
    palabras_clave
  } = req.body;

  const profesional_id = req.user.id; // viene del token

  try {
    const result = await db.query(`
      INSERT INTO servicios (
        profesional_id, nombre, descripcion, precio, duracion,
        categoria, tipo_atencion, comuna, imagenes, palabras_clave
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
      RETURNING *
    `, [
      profesional_id, nombre, descripcion, precio, duracion,
      categoria, tipo_atencion, comuna, imagenes, palabras_clave
    ]);

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error al crear servicio:', error);
    res.status(500).json({ error: 'Error al crear el servicio' });
  }
};

// Listar todos los servicios
const listarServicios = async (req, res) => {
  try {
    const result = await db.query(`SELECT * FROM servicios WHERE is_active = TRUE`);
    res.json(result.rows);
  } catch (error) {
    console.error('Error al listar servicios:', error);
    res.status(500).json({ error: 'Error al obtener servicios' });
  }
};

// Obtener detalle de un servicio
const detalleServicio = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await db.query(`SELECT * FROM servicios WHERE id = $1`, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Servicio no encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error al obtener detalle:', error);
    res.status(500).json({ error: 'Error al obtener detalle del servicio' });
  }
};

module.exports = { crearServicio, listarServicios, detalleServicio };
