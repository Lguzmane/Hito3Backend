const express = require('express');
const router = express.Router();
const {
  crearReserva,
  reservasCliente,
  reservasProfesional,
  actualizarEstado
} = require('../controllers/reservasController');
const authJWT = require('../middlewares/authMiddleware');

// Cliente crea reserva
router.post('/', authJWT(['Cliente']), crearReserva);

// Cliente ve sus reservas
router.get('/cliente', authJWT(['Cliente']), reservasCliente);

// Profesional ve sus reservas
router.get('/profesional', authJWT(['Profesional']), reservasProfesional);

// Profesional cambia estado (confirmar, cancelar)
router.put('/:id', authJWT(['Profesional']), actualizarEstado);

module.exports = router;
